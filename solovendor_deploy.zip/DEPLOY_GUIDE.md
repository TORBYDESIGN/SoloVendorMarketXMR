# SoloVendor — Full Deployment Guide

Fresh shop on a new Ubuntu 22.04 VPS in under 10 minutes.

---

## What's in this package

```
solovendor_deploy/
├── deploy.sh              ← Main automated setup script
├── update_onion.sh        ← Run this if Tor wasn't ready after deploy
├── requirements.txt       ← Python dependencies (do not edit)
├── solovendor_src.tar.gz  ← Full application source code
└── DEPLOY_GUIDE.md        ← This file
```

---

## Requirements

- Fresh **Ubuntu 22.04 LTS** VPS (AWS, DigitalOcean, Vultr, Hetzner, etc.)
- Minimum **1 GB RAM**, 20 GB disk
- Root / sudo SSH access
- The server must reach the internet (for apt and Tor)

---

## Step 1 — Upload the zip to your server

Using **WinSCP**:
1. Connect to your server (host = server IP, user = `ubuntu`, use your `.ppk` key)
2. You will land in `/home/ubuntu/` by default
3. Drag and drop `solovendor_deploy.zip` into that folder

---

## Step 2 — SSH into your server

Using **PuTTY** or any SSH client:
```
Host: YOUR_SERVER_IP
User: ubuntu
Key:  your .ppk / .pem file
```

---

## Step 3 — Run the installer

Copy and paste these commands one at a time:

```bash
sudo -i
cd /home/ubuntu
apt install -y unzip
unzip solovendor_deploy.zip -d solovendor_deploy
cd solovendor_deploy
bash deploy.sh
```

The script will ask **3 questions** then run fully automatically:

1. **Server public IP** — type your VPS IP (e.g. `44.211.121.196`)
2. **Admin password** — choose a strong password (minimum 12 characters)
3. **Admin username** — press Enter to use `admin`, or type a custom name

The whole process takes **3–5 minutes**.

---

## Step 4 — Fix nginx if you see the default page

If you visit the server IP and see the plain **"Welcome to nginx!"** page, run these:

```bash
sudo rm -f /etc/nginx/sites-enabled/default
sudo ln -sf /etc/nginx/sites-available/solovendor /etc/nginx/sites-enabled/solovendor
sudo systemctl restart nginx
```

> **Important:** Always use `restart` not `reload` — only a full restart rebinds the listening socket correctly.

---

## Step 5 — Save your credentials

At the end of the install you will see:

```
============================================
  DEPLOYMENT COMPLETE
============================================

  ⚠  TOR-ONLY MODE — port 80 is NOT publicly accessible
  ⚠  Real server IP is hidden from all visitors

  Shop URL:     http://abc123...onion/  (Tor Browser only)
  Admin panel:  http://abc123...onion/admin-panel/  (Tor Browser only)
  Admin login:  admin

  SAVE THESE — you will not see them again:
  DB password:  a1b2c3d4...
  Enc key:      7a8b9c0d...

  Admin panel access options:
  1. Tor Browser → http://abc123...onion/admin-panel/
  2. SSH tunnel  → ssh -L 8080:127.0.0.1:80 -i yourkey.pem ubuntu@SERVER_IP
     then open   → http://localhost:8080/admin-panel/
```

**Save the DB password and Enc key somewhere safe — they are never shown again.**

---

## Step 6 — Access the admin panel

The shop is **Tor-only**. Port 80 is blocked from the public internet. There are two ways in:

### Option A — Tor Browser (recommended)
1. Download Tor Browser from [torproject.org](https://www.torproject.org)
2. Open it and go to: `http://YOUR_ONION_ADDRESS.onion/admin-panel/`
3. Log in with your admin username and password

### Option B — SSH tunnel (normal browser)
Run this on your **local machine** (not the server):

**Windows (PowerShell or CMD):**
```
ssh -L 8080:127.0.0.1:80 -i C:\path\to\yourkey.pem ubuntu@YOUR_SERVER_IP
```

**Mac / Linux:**
```bash
ssh -L 8080:127.0.0.1:80 -i ~/.ssh/yourkey.pem ubuntu@YOUR_SERVER_IP
```

Keep that window open, then open a normal browser and go to:
```
http://localhost:8080/admin-panel/
```

---

## Step 7 — First-time admin setup

Log into the admin panel and configure:

1. **Site Settings** → Shop name, description, logo
2. **Site Settings** → Your PGP public key (for encrypted payment addresses)
3. **Exchange Rates** → XMR and BTC prices in GBP
   - Enter as "price of 1 coin in GBP" — e.g. XMR = `180.00`, BTC = `65000.00`
4. **Shipping** → Create at least one shipping zone and rate
5. **Products** → Add your listings
6. **Payment Addresses** → Add your XMR and BTC wallet addresses
7. **Notifications** → Set up Telegram alerts (see Step 8 below)

---

## Step 8 — Telegram notifications (optional)

Get instant alerts for every new order, payment and message.

### One-time setup:

**1. Create a bot via BotFather**
- Open Telegram → search **@BotFather** → send `/newbot`
- Choose a name and username for your bot
- BotFather gives you a token like: `1234567890:ABCdef...`

**2. Message your bot**
- In Telegram, search for your new bot by its username
- Send it `/start`

**3. Get your Chat ID**
- Open this URL in a browser (replace `YOUR_TOKEN` with your full token):
  ```
  https://api.telegram.org/botYOUR_TOKEN/getUpdates
  ```
- Example — if your token is `1234567890:ABCdef...`:
  ```
  https://api.telegram.org/bot1234567890:ABCdef.../getUpdates
  ```
  ⚠️ Note: the word `bot` must be directly before the numbers — no space, no slash.
- Find the `"id"` number inside `"from"` — that is your **Chat ID** (e.g. `8091970777`)

**4. Enter in admin panel**
- Go to **Admin Panel → Notifications**
- **Bot Token** → paste the full token from BotFather
- **Chat ID** → paste the numeric ID from step 3
- Click **Save Settings**
- Click **Send Test Message** to confirm it works

---

## If Tor wasn't ready

Sometimes Tor takes a minute longer. If the script said `"Tor onion address not ready yet"`, wait 60 seconds then run:

```bash
sudo bash /home/ubuntu/solovendor_deploy/update_onion.sh
```

Check your onion address at any time:
```bash
sudo cat /var/lib/tor/solovendor/hostname
```

---

## Useful commands

```bash
# Check all services
sudo systemctl status solovendor nginx tor postgresql

# Restart the app (after any changes)
sudo systemctl restart solovendor

# View live app logs
sudo journalctl -u solovendor -f

# View error logs
sudo tail -f /var/www/solovendor/logs/gunicorn-error.log

# View your onion address
sudo cat /var/lib/tor/solovendor/hostname

# Edit environment config
sudo nano /var/www/solovendor/.env
sudo systemctl restart solovendor   # always restart after editing .env
```

---

## Troubleshooting

### "Welcome to nginx!" default page
```bash
sudo rm -f /etc/nginx/sites-enabled/default
sudo ln -sf /etc/nginx/sites-available/solovendor /etc/nginx/sites-enabled/solovendor
sudo systemctl restart nginx
```

### nginx fails to restart (duplicate hash bucket error)
This happens if the `server_names_hash_bucket_size` line was added more than once (e.g. deploy ran + manual commands also ran). Fix it by removing all copies and adding one clean one:
```bash
sed -i '/server_names_hash_bucket_size/d' /etc/nginx/nginx.conf
sed -i '/http {/a\\tserver_names_hash_bucket_size 128;' /etc/nginx/nginx.conf
nginx -t && systemctl restart nginx
```

### App not loading / 502 Bad Gateway
```bash
sudo systemctl restart solovendor
sudo journalctl -u solovendor -n 50
```

### Static files not loading (CSS broken)
```bash
cd /var/www/solovendor
sudo -u www-data ./venv/bin/python manage.py collectstatic --noinput
sudo systemctl restart solovendor
```

### Tor onion not working
```bash
sudo systemctl status tor
sudo cat /var/log/tor/tor.log | tail -20
sudo bash /home/ubuntu/solovendor_deploy/update_onion.sh
```

### Database errors
```bash
sudo systemctl status postgresql
sudo systemctl restart postgresql
sudo systemctl restart solovendor
```

---

## Security overview

| Protection | Detail |
|------------|--------|
| Port 80 blocked | UFW only allows SSH (22). Port 80 not publicly open. |
| nginx on localhost only | Listens on `127.0.0.1:80` — not reachable from internet |
| Tor-only access | Only route in is via Tor hidden service |
| nginx version hidden | `server_tokens off` — no version fingerprinting |
| No external resources | All CSS/JS/images served locally — no CDN requests from buyer browser |
| EXIF stripping | All uploaded images have metadata removed automatically |
| Encrypted messages | AES-256-GCM encryption at rest in database |
| Argon2 passwords | Industry-standard password hashing |
| Unique keys per server | Each deployment gets its own secret key and encryption key |
| Telegram caveat | Outbound bot calls come from the server's real IP. Telegram can see it. Disable if this is a concern. |

---

## Each shop is completely independent

Every server you deploy gets:
- Its own unique **secret key** (sessions not shared between shops)
- Its own **database** (separate orders, users, products)
- Its own **message encryption key**
- Its own **.onion address**
- Its own **media files**

No link exists between shops. Compromising one does not affect others.

---

## Updating the app in future

When you receive a new deployment package:

```bash
# Stop the service
sudo systemctl stop solovendor

# Back up the database
sudo -u postgres pg_dump solovendor_db > ~/backup_$(date +%Y%m%d).sql

# Extract new code (preserves your .env and media)
sudo tar -xzf solovendor_src.tar.gz -C /var/www/ \
  --exclude='solovendor/.env' \
  --exclude='solovendor/media'

# Run migrations and collect static files
cd /var/www/solovendor
sudo -u www-data ./venv/bin/python manage.py migrate --noinput
sudo -u www-data ./venv/bin/python manage.py collectstatic --noinput

# Fix permissions and restart
sudo chown -R www-data:www-data /var/www/solovendor
sudo systemctl restart solovendor
```
