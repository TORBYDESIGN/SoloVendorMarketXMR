#!/bin/bash
# =============================================================================
# SoloVendor - Automated Deployment Script
# Ubuntu 22.04 LTS — Tor-only mode (real IP never exposed)
# Run as: sudo bash deploy.sh
# =============================================================================
set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
info()  { echo -e "${CYAN}[INFO]${NC}  $1"; }
ok()    { echo -e "${GREEN}[OK]${NC}    $1"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $1"; }
die()   { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

[[ $EUID -ne 0 ]] && die "Run as root: sudo bash deploy.sh"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ── Prompts ───────────────────────────────────────────────────────────────────
echo ""
echo -e "${CYAN}======================================${NC}"
echo -e "${CYAN}  SoloVendor Deployment Setup${NC}"
echo -e "${CYAN}======================================${NC}"
echo ""
info "Detecting server public IP..."
SERVER_IP=$(curl -s --max-time 3 http://169.254.169.254/latest/meta-data/public-ipv4 2>/dev/null || true)
[[ -z "$SERVER_IP" ]] && SERVER_IP=$(curl -s --max-time 5 https://api.ipify.org 2>/dev/null || true)
[[ -z "$SERVER_IP" ]] && SERVER_IP=$(curl -s --max-time 5 http://ifconfig.me 2>/dev/null || true)
[[ -z "$SERVER_IP" ]] && SERVER_IP="UNKNOWN"
ok "Server IP: ${SERVER_IP}"

read -sp "Set admin password (min 12 chars): " ADMIN_PASS
echo ""
[[ ${#ADMIN_PASS} -lt 12 ]] && die "Password must be at least 12 characters."

read -p "Admin username [admin]: " ADMIN_USER
ADMIN_USER="${ADMIN_USER:-admin}"

APP_DIR=/var/www/solovendor
DB_NAME=solovendor_db
DB_USER=solovendor
DB_PASS=$(openssl rand -hex 24)
SECRET_KEY=$(python3 -c "import secrets,string; print(''.join(secrets.choice(string.ascii_letters+string.digits+'!@#\$%^&*(-_=+)') for _ in range(50)))")
MSG_KEY=$(openssl rand -hex 32)

# ── 1. System packages ────────────────────────────────────────────────────────
info "Installing system packages..."
apt-get update -qq
apt-get install -y -qq \
    nginx postgresql postgresql-contrib \
    tor ufw gnupg apt-transport-https \
    build-essential libpq-dev \
    openssl curl unzip software-properties-common
ok "Base packages installed."

# -- Python 3.11 — try default repos first, fall back to deadsnakes PPA ------
info "Installing Python 3.11..."
if apt-get install -y -qq python3.11 python3.11-venv python3.11-dev 2>/dev/null; then
    ok "Python 3.11 installed from default repos."
else
    info "python3.11 not in default repos — adding deadsnakes PPA..."
    add-apt-repository -y ppa:deadsnakes/ppa
    apt-get update -qq
    apt-get install -y -qq python3.11 python3.11-venv python3.11-dev
    ok "Python 3.11 installed from deadsnakes PPA."
fi

# -- 1b. Upgrade Tor to latest from official Tor Project repo -----------------
info "Upgrading Tor to latest version (Tor Project official repo)..."
DISTRO_CODENAME=$(lsb_release -sc 2>/dev/null || echo "jammy")
curl -s https://deb.torproject.org/torproject.org/A3C4F0F979CAA22CDBA8F512EE8CBC9E886DDD89.asc | gpg --dearmor | tee /usr/share/keyrings/tor-archive-keyring.gpg > /dev/null
echo "deb [signed-by=/usr/share/keyrings/tor-archive-keyring.gpg] https://deb.torproject.org/torproject.org ${DISTRO_CODENAME} main" > /etc/apt/sources.list.d/tor.list
echo "deb-src [signed-by=/usr/share/keyrings/tor-archive-keyring.gpg] https://deb.torproject.org/torproject.org ${DISTRO_CODENAME} main" >> /etc/apt/sources.list.d/tor.list
apt-get update -qq
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq tor deb.torproject.org-keyring 2>/dev/null || \
    DEBIAN_FRONTEND=noninteractive apt-get install -y -qq tor
ok "Tor upgraded to latest."

# ── 2. Firewall ───────────────────────────────────────────────────────────────
info "Configuring firewall (Tor-only — port 80 blocked from public internet)..."
ufw --force reset
ufw default deny incoming
ufw default allow outgoing
ufw allow 22/tcp comment 'SSH admin access'
ufw --force enable
ok "Firewall active. Only SSH (port 22) open. Shop reachable via Tor only."

# ── 3. PostgreSQL ─────────────────────────────────────────────────────────────
info "Setting up PostgreSQL..."
systemctl enable postgresql --quiet
systemctl start postgresql

sudo -u postgres psql -c "CREATE USER ${DB_USER} WITH PASSWORD '${DB_PASS}';" 2>/dev/null || \
    sudo -u postgres psql -c "ALTER USER ${DB_USER} WITH PASSWORD '${DB_PASS}';"
sudo -u postgres psql -c "CREATE DATABASE ${DB_NAME} OWNER ${DB_USER};" 2>/dev/null || true
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE ${DB_NAME} TO ${DB_USER};"
ok "PostgreSQL ready."

# ── 4. Extract app files ──────────────────────────────────────────────────────
info "Extracting application files..."
mkdir -p ${APP_DIR}
tar -xzf "${SCRIPT_DIR}/solovendor_src.tar.gz" -C ${APP_DIR}/
mkdir -p ${APP_DIR}/{media,staticfiles,logs}
touch ${APP_DIR}/logs/{app.log,security.log,gunicorn-access.log,gunicorn-error.log}
ok "Application files extracted."

# ── 5. Write .env ─────────────────────────────────────────────────────────────
info "Writing .env file..."
cat > ${APP_DIR}/.env << ENVEOF
DEBUG=False
SECRET_KEY=${SECRET_KEY}
DATABASE_URL=postgresql://${DB_USER}:${DB_PASS}@localhost:5432/${DB_NAME}
ALLOWED_HOSTS=localhost,127.0.0.1
MEDIA_ROOT=${APP_DIR}/media
STATIC_ROOT=${APP_DIR}/staticfiles
MESSAGE_ENCRYPTION_KEY=${MSG_KEY}
TELEGRAM_ENABLED=False
TELEGRAM_BOT_TOKEN=
TELEGRAM_CHAT_ID=
ENVEOF
ok ".env written."

# ── 6. DB heal script — auto-syncs PostgreSQL password on every service start ─
info "Installing database heal script..."
cat > /usr/local/bin/solovendor-db-heal.sh << 'HEALEOF'
#!/bin/bash
# Auto-heal: re-sync PostgreSQL password from .env before service starts.
# Prevents 500 errors caused by password drift after restarts or updates.
ENV_FILE=/var/www/solovendor/.env
[[ ! -f "$ENV_FILE" ]] && exit 0
DB_PASS=$(grep -oP 'solovendor:\K[^@]+' "$ENV_FILE" 2>/dev/null || true)
[[ -z "$DB_PASS" ]] && exit 0
su - postgres -s /bin/bash -c "psql -c \"ALTER USER solovendor WITH PASSWORD '${DB_PASS}';\"" 2>/dev/null || true
exit 0
HEALEOF
chmod +x /usr/local/bin/solovendor-db-heal.sh
ok "DB heal script installed."

# ── 7. Permissions ────────────────────────────────────────────────────────────
info "Setting file ownership..."
chown -R www-data:www-data ${APP_DIR}
chmod 750 ${APP_DIR}
chmod 600 ${APP_DIR}/.env
chmod 755 ${APP_DIR}/{media,staticfiles,logs}
ok "Ownership set."

# ── 8. Python virtualenv ──────────────────────────────────────────────────────
info "Creating Python virtual environment..."
python3.11 -m venv ${APP_DIR}/venv
${APP_DIR}/venv/bin/pip install --upgrade pip -q
${APP_DIR}/venv/bin/pip install -r "${SCRIPT_DIR}/requirements.txt" -q
chown -R www-data:www-data ${APP_DIR}/venv
ok "Python environment ready."

# ── 9. Migrations + static ────────────────────────────────────────────────────
info "Running database migrations..."
cd ${APP_DIR}
sudo -u www-data ${APP_DIR}/venv/bin/python manage.py migrate --noinput 2>&1 | tail -5
ok "Migrations complete."

info "Collecting static files..."
sudo -u www-data ${APP_DIR}/venv/bin/python manage.py collectstatic --noinput -v 0
ok "Static files collected."

# ── 10. Create admin user ─────────────────────────────────────────────────────
info "Creating admin user '${ADMIN_USER}'..."
sudo -u www-data ${APP_DIR}/venv/bin/python manage.py shell -c "
from accounts.models import User
if not User.objects.filter(username='${ADMIN_USER}').exists():
    u = User(username='${ADMIN_USER}', role='admin')
    u.set_password('${ADMIN_PASS}')
    u.save()
    print('Admin created.')
else:
    print('Admin already exists - skipped.')
"
ok "Admin user ready."

# ── 11. Tor hidden service ────────────────────────────────────────────────────
info "Configuring Tor hidden service..."
mkdir -p /var/lib/tor/solovendor
chown debian-tor:debian-tor /var/lib/tor/solovendor
chmod 700 /var/lib/tor/solovendor

# Enable Tor SOCKS proxy for outbound API calls (payment verification, Telegram)
sed -i 's/^SocksPort 0/SocksPort 127.0.0.1:9050/' /etc/tor/torrc 2>/dev/null || true
grep -q 'SocksPort 127.0.0.1:9050' /etc/tor/torrc || echo 'SocksPort 127.0.0.1:9050' >> /etc/tor/torrc

if ! grep -q "HiddenServiceDir /var/lib/tor/solovendor" /etc/tor/torrc; then
    printf '\n# SoloVendor hidden service\nHiddenServiceDir /var/lib/tor/solovendor\nHiddenServicePort 80 127.0.0.1:80\n' >> /etc/tor/torrc
fi
systemctl enable tor --quiet
systemctl restart tor

info "Waiting for Tor to generate .onion address (up to 60s)..."
for i in $(seq 1 60); do
    [[ -f /var/lib/tor/solovendor/hostname ]] && break
    sleep 1
done

if [[ -f /var/lib/tor/solovendor/hostname ]]; then
    ONION=$(cat /var/lib/tor/solovendor/hostname)
    ok "Onion address: ${ONION}"
else
    warn "Tor hostname not ready. Run: sudo bash ${SCRIPT_DIR}/update_onion.sh later."
    ONION="PENDING"
fi

# ── 12. Update settings with onion address ────────────────────────────────────
if [[ "$ONION" != "PENDING" ]]; then
    info "Updating config with onion address..."
    sed -i "s|ALLOWED_HOSTS=.*|ALLOWED_HOSTS=localhost,127.0.0.1,${ONION}|" ${APP_DIR}/.env
    echo "ONION_HOST=${ONION}" >> ${APP_DIR}/.env
    ok "Config updated with onion address."
fi

# ── 13. Systemd service — with DB heal on every start ────────────────────────
info "Installing systemd service..."
cat > /etc/systemd/system/solovendor.service << SVCEOF
[Unit]
Description=Solo Vendor Gunicorn WSGI server
After=network.target postgresql.service
Requires=postgresql.service

[Service]
Type=notify
User=www-data
Group=www-data
WorkingDirectory=${APP_DIR}
EnvironmentFile=${APP_DIR}/.env
ExecStartPre=+/usr/local/bin/solovendor-db-heal.sh
ExecStart=${APP_DIR}/venv/bin/gunicorn \\
    --workers 3 \\
    --worker-class sync \\
    --timeout 120 \\
    --bind unix:/run/solovendor/gunicorn.sock \\
    --access-logfile ${APP_DIR}/logs/gunicorn-access.log \\
    --error-logfile ${APP_DIR}/logs/gunicorn-error.log \\
    --log-level warning \\
    --pid /run/solovendor/gunicorn.pid \\
    solovendor.wsgi:application
RuntimeDirectory=solovendor
RuntimeDirectoryMode=0755
PIDFile=/run/solovendor/gunicorn.pid
ExecReload=/bin/kill -s HUP \$MAINPID
KillMode=mixed
TimeoutStopSec=5
PrivateTmp=true
ProtectSystem=strict
ReadWritePaths=${APP_DIR} /run/solovendor

[Install]
WantedBy=multi-user.target
SVCEOF
systemctl daemon-reload
systemctl enable solovendor --quiet
systemctl start solovendor
sleep 2
systemctl is-active --quiet solovendor && ok "SoloVendor service started." || die "Service failed. Run: journalctl -u solovendor -n 30"

# ── 14. Verify DB connection ──────────────────────────────────────────────────
info "Verifying database connection..."
if sudo -u www-data ${APP_DIR}/venv/bin/python -c \
    "import django; django.setup(); from django.db import connection; connection.ensure_connection(); print('DB OK')" \
    2>/dev/null; then
    ok "Database connection verified."
else
    warn "DB connection check failed — re-syncing password..."
    /usr/local/bin/solovendor-db-heal.sh
    systemctl restart solovendor
    sleep 2
    ok "Service restarted with synced DB password."
fi

# ── 15. Nginx ─────────────────────────────────────────────────────────────────
info "Configuring Nginx (localhost-only, no public IP exposure)..."

sed -i '/server_names_hash_bucket_size/d' /etc/nginx/nginx.conf
sed -i '/http {/a\\tserver_names_hash_bucket_size 128;' /etc/nginx/nginx.conf
sed -i 's/# server_tokens off;/server_tokens off;/' /etc/nginx/nginx.conf

cat > /etc/nginx/sites-available/solovendor << 'NGINXEOF'
server {
    listen 127.0.0.1:80 default_server;
    server_name _;
    client_max_body_size 10M;
    access_log /var/log/nginx/solovendor-access.log;
    error_log  /var/log/nginx/solovendor-error.log warn;

    location /static/ {
        alias /var/www/solovendor/staticfiles/;
        expires 7d;
        add_header Cache-Control "public, no-transform";
        access_log off;
    }
    location /media/ {
        alias /var/www/solovendor/media/;
        location ~* \.(jpg|jpeg|png|webp|gif)$ { expires 30d; add_header Cache-Control "public"; }
        location ~* [^.]+$ { deny all; }
        access_log off;
    }
    location ~ /\.   { deny all; }
    location ~ \.env { deny all; }
    location ~ \.py$ { deny all; }
    location / {
        proxy_pass http://unix:/run/solovendor/gunicorn.sock;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_redirect off;
        proxy_buffering on;
        proxy_buffer_size 8k;
        proxy_buffers 16 8k;
        proxy_connect_timeout 30s;
        proxy_read_timeout 60s;
        proxy_send_timeout 60s;
    }
    add_header X-Frame-Options DENY always;
    add_header X-Content-Type-Options nosniff always;
    add_header Referrer-Policy "no-referrer" always;
}
NGINXEOF

if [[ "$ONION" != "PENDING" ]]; then
    cat >> /etc/nginx/sites-available/solovendor << NGINXEOF

server {
    listen 127.0.0.1:80;
    server_name ${ONION};
    client_max_body_size 10M;
    access_log /var/log/nginx/solovendor-tor.log;
    error_log  /var/log/nginx/solovendor-error.log warn;
    location /static/ { alias ${APP_DIR}/staticfiles/; expires 7d; access_log off; }
    location /media/  { alias ${APP_DIR}/media/; }
    location ~ /\.  { deny all; }
    location ~ \.py\$ { deny all; }
    location / {
        proxy_pass http://unix:/run/solovendor/gunicorn.sock;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_redirect off;
    }
    add_header X-Frame-Options DENY always;
    add_header X-Content-Type-Options nosniff always;
    add_header Referrer-Policy "no-referrer" always;
}
NGINXEOF
fi

ln -sf /etc/nginx/sites-available/solovendor /etc/nginx/sites-enabled/solovendor
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl enable nginx --quiet && systemctl restart nginx
ok "Nginx configured — listening on localhost only."

# ── Done ──────────────────────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}============================================${NC}"
echo -e "${GREEN}  DEPLOYMENT COMPLETE${NC}"
echo -e "${GREEN}============================================${NC}"
echo ""
echo -e "${YELLOW}  ⚠  TOR-ONLY MODE — port 80 is NOT publicly accessible${NC}"
echo -e "${YELLOW}  ⚠  Real server IP is hidden from all visitors${NC}"
echo ""
[[ "$ONION" != "PENDING" ]] && echo -e "  Shop URL:     ${CYAN}http://${ONION}/${NC}  (Tor Browser only)"
[[ "$ONION" != "PENDING" ]] && echo -e "  Admin panel:  ${CYAN}http://${ONION}/admin-panel/${NC}  (Tor Browser only)"
echo -e "  Admin login:  ${CYAN}${ADMIN_USER}${NC}"
echo ""
echo -e "${YELLOW}  SAVE THESE — you will not see them again:${NC}"
echo -e "  DB password:  ${DB_PASS}"
echo -e "  Enc key:      ${MSG_KEY}"
echo ""
echo -e "${CYAN}  Admin panel access options:${NC}"
echo -e "  1. Tor Browser → http://${ONION}/admin-panel/"
echo -e "  2. SSH tunnel  → ssh -L 8080:127.0.0.1:80 -i yourkey.pem ubuntu@${SERVER_IP}"
echo -e "     then open   → http://localhost:8080/admin-panel/"
echo ""
if [[ "$ONION" == "PENDING" ]]; then
    echo -e "${YELLOW}  Tor not ready yet. Once Tor is up run:${NC}"
    echo -e "  sudo bash ${SCRIPT_DIR}/update_onion.sh"
    echo ""
fi
