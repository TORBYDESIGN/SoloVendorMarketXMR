#!/bin/bash
# Run this if Tor wasn't ready when deploy.sh finished
# sudo bash update_onion.sh
set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; CYAN='\033[0;36m'; NC='\033[0m'
ok()   { echo -e "${GREEN}[OK]${NC}    $1"; }
die()  { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

APP_DIR=/var/www/solovendor
ONION_FILE=/var/lib/tor/solovendor/hostname

[[ ! -f "$ONION_FILE" ]] && die "Tor hostname not found. Is Tor running? Try: sudo systemctl status tor"

ONION=$(cat "$ONION_FILE")
ok "Onion address: $ONION"

# Update ALLOWED_HOSTS in .env (append onion if not already there)
if grep -q "^ALLOWED_HOSTS=" "${APP_DIR}/.env"; then
    CURRENT=$(grep "^ALLOWED_HOSTS=" "${APP_DIR}/.env" | cut -d= -f2)
    if [[ "$CURRENT" != *"$ONION"* ]]; then
        sed -i "s|^ALLOWED_HOSTS=.*|ALLOWED_HOSTS=${CURRENT},${ONION}|" "${APP_DIR}/.env"
    fi
fi

# Write ONION_HOST to .env (used by settings.py for ALLOWED_HOSTS and CSRF)
if grep -q "^ONION_HOST=" "${APP_DIR}/.env"; then
    sed -i "s|^ONION_HOST=.*|ONION_HOST=${ONION}|" "${APP_DIR}/.env"
else
    echo "ONION_HOST=${ONION}" >> "${APP_DIR}/.env"
fi
ok ".env updated"

# Append onion server block to nginx — localhost-only, never public
if ! grep -q "server_name ${ONION}" /etc/nginx/sites-available/solovendor; then
    cat >> /etc/nginx/sites-available/solovendor << NGINXEOF

server {
    listen 127.0.0.1:80;
    server_name ${ONION};
    client_max_body_size 10M;
    access_log /var/log/nginx/solovendor-tor.log;
    error_log /var/log/nginx/solovendor-error.log warn;
    location /static/ { alias ${APP_DIR}/staticfiles/; expires 7d; access_log off; }
    location /media/  { alias ${APP_DIR}/media/; }
    location ~ /\.  { deny all; }
    location ~ \.py\$ { deny all; }
    location / {
        proxy_pass http://unix:/run/solovendor/gunicorn.sock;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_redirect off;
    }
    add_header X-Frame-Options DENY always;
    add_header X-Content-Type-Options nosniff always;
    add_header Referrer-Policy "no-referrer" always;
}
NGINXEOF
    ok "nginx server block added (localhost-only)"
else
    ok "nginx already configured for this onion"
fi

nginx -t && systemctl reload nginx
systemctl restart solovendor
ok "Services reloaded"

echo ""
echo "  Shop URL:    http://${ONION}/   (Tor Browser only)"
echo "  Admin panel: http://${ONION}/admin-panel/"
